import urllib.request
import xbmc
import xbmcgui
import xbmcvfs
import zipfile
import os

BUILD_URL = "https://github.com/Dekivas/dejan-kodi-build/releases/download/v1.1/DekivaS+Build.zip"

GUI_URL = "https://github.com/Dekivas/dejan-kodi-build/releases/download/v1.1/DekivaS+Build_guisettings.zip"

kodi_home = xbmcvfs.translatePath("special://home/")
userdata = xbmcvfs.translatePath("special://masterprofile/")
packages = xbmcvfs.translatePath("special://home/packages/")

if not os.path.exists(packages):
    os.makedirs(packages)

build_zip = os.path.join(packages, "DekivaS+Build.zip")
gui_zip = os.path.join(packages, "DekivaS+Build_guisettings.zip")

try:

    answer = xbmcgui.Dialog().yesno(
        "DekivaS Installer",
        "Preuzeti i instalirati DekivaS Build?"
    )

    if answer:

        xbmcgui.Dialog().notification(
            "DekivaS Installer",
            "Preuzimanje Build ZIP...",
            xbmcgui.NOTIFICATION_INFO,
            3000
        )

        urllib.request.urlretrieve(BUILD_URL, build_zip)

        xbmcgui.Dialog().notification(
            "DekivaS Installer",
            "Raspakivanje Build ZIP...",
            xbmcgui.NOTIFICATION_INFO,
            3000
        )

        with zipfile.ZipFile(build_zip, 'r') as zip_ref:
            zip_ref.extractall(kodi_home)

        xbmcgui.Dialog().notification(
            "DekivaS Installer",
            "Preuzimanje GUI ZIP...",
            xbmcgui.NOTIFICATION_INFO,
            3000
        )

        urllib.request.urlretrieve(GUI_URL, gui_zip)

        xbmcgui.Dialog().notification(
            "DekivaS Installer",
            "Vracanje GUI Settings...",
            xbmcgui.NOTIFICATION_INFO,
            3000
        )

        with zipfile.ZipFile(gui_zip, 'r') as zip_ref:
            zip_ref.extractall(userdata)

        xbmcgui.Dialog().ok(
            "DekivaS Installer",
            "Build i GUI Settings su uspesno instalirani.\n\nKodi ce se sada zatvoriti."
        )

        xbmc.executebuiltin("Quit")

except Exception as e:

    xbmcgui.Dialog().ok(
        "DekivaS Installer - Greska",
        str(e)
    )