import urllib.request
import xbmc
import xbmcgui
import xbmcvfs
import os

BUILD_URL = "https://github.com/Dekivas/dejan-kodi-build/releases/download/v1.2/DekivaS+Build.zip"
GUI_URL = "https://github.com/Dekivas/dejan-kodi-build/releases/download/v1.2/DekivaS+Build_guisettings.zip"

kodi_home = xbmcvfs.translatePath("special://home/")
userdata = xbmcvfs.translatePath("special://masterprofile/")
packages = xbmcvfs.translatePath("special://home/packages/")

if not os.path.exists(packages):
    os.makedirs(packages)

build_zip = os.path.join(packages, "DekivaS+Build.zip")
gui_zip = os.path.join(packages, "DekivaS+Build_guisettings.zip")
ps_script = os.path.join(packages, "DekivaS-install.ps1")
vbs_script = os.path.join(packages, "DekivaS-launch.vbs")
log_file = os.path.join(packages, "DekivaS-install.log")
launch_log = os.path.join(packages, "DekivaS-launch.log")


def ps_quote(value):
    return "'" + value.replace("'", "''") + "'"


def vb_quote(value):
    return '"' + value.replace('"', '""') + '"'


try:
    if not xbmc.getCondVisibility("System.Platform.Windows"):
        xbmcgui.Dialog().ok(
            "DekivaS Installer",
            "Ova verzija je namenjena samo za Windows."
        )
    else:
        answer = xbmcgui.Dialog().yesno(
            "DekivaS Installer",
            "Preuzeti i instalirati DekivaS Build?"
        )

        if answer:
            xbmcgui.Dialog().notification(
                "DekivaS Installer",
                "Preuzimanje Build ZIP...",
                xbmcgui.NOTIFICATION_INFO,
                3000
            )

            urllib.request.urlretrieve(BUILD_URL, build_zip)

            xbmcgui.Dialog().notification(
                "DekivaS Installer",
                "Preuzimanje GUI ZIP...",
                xbmcgui.NOTIFICATION_INFO,
                3000
            )

            urllib.request.urlretrieve(GUI_URL, gui_zip)

            script = r"""
$ErrorActionPreference = 'Stop'

$BuildZip = BUILD_PATH
$GuiZip = GUI_PATH
$KodiHome = KODI_HOME_PATH
$UserData = USERDATA_PATH
$Log = LOG_PATH

Add-Type -AssemblyName System.Windows.Forms

try {
    'Cekam da se Kodi potpuno ugasi...' | Set-Content -LiteralPath $Log

    while (Get-Process -Name 'Kodi' -ErrorAction SilentlyContinue) {
        Start-Sleep -Seconds 1
    }

    'Kodi je ugasen. Raspakujem Build...' | Add-Content -LiteralPath $Log

    Expand-Archive -LiteralPath $BuildZip -DestinationPath $KodiHome -Force

    'Build je raspakovan. Primenjujem GUI podesavanja...' | Add-Content -LiteralPath $Log

    Expand-Archive -LiteralPath $GuiZip -DestinationPath $UserData -Force

    'SUCCESS: Build i GUI podesavanja su uspesno primenjeni.' |
        Add-Content -LiteralPath $Log

    [System.Windows.Forms.MessageBox]::Show(
        "DekivaS Build je uspesno instaliran!`r`n`r`nSada mozete bezbedno pokrenuti Kodi.",
        "DekivaS Installer - Instalacija zavrsena",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
}
catch {
    $errorText = $_ | Out-String

    'GRESKA:' | Add-Content -LiteralPath $Log
    $errorText | Add-Content -LiteralPath $Log

    [System.Windows.Forms.MessageBox]::Show(
        "Doslo je do greske tokom instalacije:`r`n`r`n$($_.Exception.Message)`r`n`r`Proverite DekivaS-install.log.",
        "DekivaS Installer - Greska",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
}
"""

            script = script.replace("BUILD_PATH", ps_quote(build_zip))
            script = script.replace("GUI_PATH", ps_quote(gui_zip))
            script = script.replace("KODI_HOME_PATH", ps_quote(kodi_home))
            script = script.replace("USERDATA_PATH", ps_quote(userdata))
            script = script.replace("LOG_PATH", ps_quote(log_file))

            with open(ps_script, "w", encoding="utf-16") as f:
                f.write(script)

            powershell = os.path.join(
                os.environ.get("WINDIR", r"C:\Windows"),
                "System32",
                "WindowsPowerShell",
                "v1.0",
                "powershell.exe"
            )

            command = (
                '"' + powershell + '"'
                ' -NoProfile -ExecutionPolicy Bypass'
                ' -WindowStyle Hidden'
                ' -File "' + ps_script + '"'
            )

            vbs = (
                'On Error Resume Next\n'
                'Set fso = CreateObject("Scripting.FileSystemObject")\n'
                'Set log = fso.OpenTextFile('
                + vb_quote(launch_log) + ', 8, True)\n'
                'log.WriteLine Now & " - VBS pokrenut"\n'
                'log.Close\n'
                'Set shell = CreateObject("WScript.Shell")\n'
                'shell.Run ' + vb_quote(command) + ', 0, False\n'
            )

            with open(vbs_script, "w", encoding="utf-16") as f:
                f.write(vbs)

            os.startfile(vbs_script)

            xbmcgui.Dialog().ok(
                "DekivaS Installer",
                "ZIP fajlovi su preuzeti. Kodi će se sada zatvoriti kako bi instalater "
                "raspakovao build.\n\nNemojte pokretati ponovo KODI dok se ne pojavi "
                "popup poruka da je završena instalacija!"
            )

            xbmc.executebuiltin("Quit")

except Exception as e:
    xbmcgui.Dialog().ok(
        "DekivaS Installer - Greska",
        str(e)
    )
