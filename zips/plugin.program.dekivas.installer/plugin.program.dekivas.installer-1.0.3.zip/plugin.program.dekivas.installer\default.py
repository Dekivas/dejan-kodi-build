﻿import urllib.request
import xbmc
import xbmcgui
import xbmcvfs
import os
import subprocess

BUILD_URL = "https://github.com/Dekivas/dejan-kodi-build/releases/download/v1.2/DekivaS+Build.zip"
GUI_URL = "https://github.com/Dekivas/dejan-kodi-build/releases/download/v1.2/DekivaS+Build_guisettings.zip"

kodi_home = xbmcvfs.translatePath("special://home/")
userdata = xbmcvfs.translatePath("special://masterprofile/")
packages = xbmcvfs.translatePath("special://home/packages/")

if not os.path.exists(packages):
    os.makedirs(packages)

build_zip = os.path.join(packages, "DekivaS+Build.zip")
gui_zip = os.path.join(packages, "DekivaS+Build_guisettings.zip")
ps_script = os.path.join(packages, "DekivaS-install.ps1")
log_file = os.path.join(packages, "DekivaS-install.log")


def ps_quote(value):
    return "'" + value.replace("'", "''") + "'"


try:
    answer = xbmcgui.Dialog().yesno(
        "DekivaS Installer",
        "Preuzeti i instalirati DekivaS Build?"
    )

    if answer:
        xbmcgui.Dialog().notification(
            "DekivaS Installer",
            "Preuzimanje Build ZIP...",
            xbmcgui.NOTIFICATION_INFO,
            3000
        )

        urllib.request.urlretrieve(BUILD_URL, build_zip)

        xbmcgui.Dialog().notification(
            "DekivaS Installer",
            "Preuzimanje GUI ZIP...",
            xbmcgui.NOTIFICATION_INFO,
            3000
        )

        urllib.request.urlretrieve(GUI_URL, gui_zip)

        script = r"""
$ErrorActionPreference = 'Stop'

$BuildZip = BUILD_PATH
$GuiZip = GUI_PATH
$KodiHome = KODI_HOME_PATH
$UserData = USERDATA_PATH
$Log = LOG_PATH

try {
    'Cekam da se Kodi potpuno ugasi...' | Set-Content -LiteralPath $Log

    while (Get-Process -Name 'Kodi' -ErrorAction SilentlyContinue) {
        Start-Sleep -Seconds 1
    }

    'Kodi je ugasen. Raspakujem Build...' | Add-Content -LiteralPath $Log

    Expand-Archive -LiteralPath $BuildZip -DestinationPath $KodiHome -Force

    'Build je raspakovan. Primenjujem GUI podesavanja...' | Add-Content -LiteralPath $Log

    Expand-Archive -LiteralPath $GuiZip -DestinationPath $UserData -Force

    'SUCCESS: Build i GUI podesavanja su uspesno primenjeni.' |
        Add-Content -LiteralPath $Log
}
catch {
    'GRESKA:' | Add-Content -LiteralPath $Log
    $_ | Out-String | Add-Content -LiteralPath $Log
}
"""

        script = script.replace("BUILD_PATH", ps_quote(build_zip))
        script = script.replace("GUI_PATH", ps_quote(gui_zip))
        script = script.replace("KODI_HOME_PATH", ps_quote(kodi_home))
        script = script.replace("USERDATA_PATH", ps_quote(userdata))
        script = script.replace("LOG_PATH", ps_quote(log_file))

        with open(ps_script, "w", encoding="utf-8") as f:
            f.write(script)

        powershell = os.path.join(
            os.environ.get("WINDIR", r"C:\Windows"),
            "System32",
            "WindowsPowerShell",
            "v1.0",
            "powershell.exe"
        )

        flags = (
            subprocess.DETACHED_PROCESS |
            subprocess.CREATE_NEW_PROCESS_GROUP
        )

        subprocess.Popen(
            [
                powershell,
                "-NoProfile",
                "-ExecutionPolicy", "Bypass",
                "-WindowStyle", "Hidden",
                "-File", ps_script
            ],
            creationflags=flags,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True
        )

        xbmcgui.Dialog().ok(
            "DekivaS Installer",
            "Oba ZIP fajla su preuzeta.\n\n"
            "Kodi ce se sada zatvoriti. Instalacija ce se nastaviti "
            "nakon potpunog gasenja Kodi-ja."
        )

        xbmc.executebuiltin("Quit")

except Exception as e:
    xbmcgui.Dialog().ok(
        "DekivaS Installer - Greska",
        str(e)
    )