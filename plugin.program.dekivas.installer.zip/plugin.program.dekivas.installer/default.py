﻿
import urllib.request
import xbmc
import xbmcgui
import xbmcvfs
import zipfile
import os
import subprocess

BUILD_URL = "https://github.com/Dekivas/dejan-kodi-build/releases/download/v1.1/DekivaS+Build.zip"
GUI_URL = "https://github.com/Dekivas/dejan-kodi-build/releases/download/v1.1/DekivaS+Build_guisettings.zip"

kodi_home = xbmcvfs.translatePath("special://home/")
userdata = xbmcvfs.translatePath("special://masterprofile/")
packages = xbmcvfs.translatePath("special://home/packages/")

if not os.path.exists(packages):
    os.makedirs(packages)

build_zip = os.path.join(packages, "DekivaS+Build.zip")
gui_zip = os.path.join(packages, "DekivaS+Build_guisettings.zip")
ps_script = os.path.join(packages, "DekivaS-apply-gui.ps1")

def ps_quote(value):
    return "'" + value.replace("'", "''") + "'"

try:
    answer = xbmcgui.Dialog().yesno(
        "DekivaS Installer",
        "Preuzeti i instalirati DekivaS Build?"
    )

    if answer:
        xbmcgui.Dialog().notification(
            "DekivaS Installer",
            "Preuzimanje Build ZIP...",
            xbmcgui.NOTIFICATION_INFO,
            3000
        )

        urllib.request.urlretrieve(BUILD_URL, build_zip)

        with zipfile.ZipFile(build_zip, 'r') as zip_ref:
            zip_ref.extractall(kodi_home)

        xbmcgui.Dialog().notification(
            "DekivaS Installer",
            "Preuzimanje GUI ZIP...",
            xbmcgui.NOTIFICATION_INFO,
            3000
        )

        urllib.request.urlretrieve(GUI_URL, gui_zip)

        script = r"""
$ErrorActionPreference = 'Stop'
$GuiZip = GUI_PATH
$UserData = USERDATA_PATH
$Log = LOG_PATH

'Waiting for Kodi to close...' | Set-Content -LiteralPath $Log

while (Get-Process -Name 'Kodi' -ErrorAction SilentlyContinue) {
    Start-Sleep -Seconds 1
}

try {
    Expand-Archive -LiteralPath $GuiZip -DestinationPath $UserData -Force
    'SUCCESS: GUI settings applied.' | Add-Content -LiteralPath $Log
}
catch {
    $_ | Out-String | Add-Content -LiteralPath $Log
}
"""
        script = script.replace("GUI_PATH", ps_quote(gui_zip))
        script = script.replace("USERDATA_PATH", ps_quote(userdata))
        script = script.replace(
            "LOG_PATH",
            ps_quote(os.path.join(packages, "DekivaS-GUI-apply.log"))
        )

        with open(ps_script, "w", encoding="utf-8") as f:
            f.write(script)

        powershell = os.path.join(
            os.environ.get("WINDIR", r"C:\Windows"),
            "System32",
            "WindowsPowerShell",
            "v1.0",
            "powershell.exe"
        )

        flags = (
            subprocess.DETACHED_PROCESS |
            subprocess.CREATE_NEW_PROCESS_GROUP
        )

        subprocess.Popen(
            [
                powershell,
                "-NoProfile",
                "-ExecutionPolicy", "Bypass",
                "-WindowStyle", "Hidden",
                "-File", ps_script
            ],
            creationflags=flags,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True
        )

        xbmcgui.Dialog().ok(
            "DekivaS Installer",
            "Build je raspakovan.\n\n"
            "GUI podesavanja ce biti primenjena nakon potpunog "
            "gasenja Kodi-ja.\n\nKodi ce se sada zatvoriti."
        )

        xbmc.executebuiltin("Quit")

except Exception as e:
    xbmcgui.Dialog().ok(
        "DekivaS Installer - Greska",
        str(e)
    )

